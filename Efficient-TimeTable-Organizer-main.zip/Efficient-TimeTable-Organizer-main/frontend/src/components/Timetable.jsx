// Timetable.jsx
import React from "react";

const Timetable = () => {
  return (
    <div style={{ padding: "30px", fontFamily: "Arial, sans-serif" }}>
      <h2 style={{ textAlign: "center" }}>Generated Timetable</h2>
      <p style={{ textAlign: "center" }}>This is where your timetable details will appear.</p>
    </div>
  );
};

export default Timetable;
